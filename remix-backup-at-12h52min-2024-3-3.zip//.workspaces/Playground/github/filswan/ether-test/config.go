package main

// Shared RPC URL
const rpcURL = "https://rpc-testnet.swanchain.io" // Replace with your testnet's RPC URL
