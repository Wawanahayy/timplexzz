<!DOCTYPE html>
<html class="overflow-hidden">
<head><base href="/">
<meta charset="utf-8">

<meta http-equiv="X-UA-Compatible" content="chrome=1">
<title>Remix - Ethereum IDE</title>
<link rel="stylesheet" href="assets/css/pygment_trac.css">
<link rel="icon" type="x-icon" href="assets/img/remix-logo-blue.png">
<link rel="stylesheet" href="assets/css/intro.js/4.1.0/introjs.min.css">
<link rel="stylesheet" href="assets/fontawesome/css/all.css">
<script src="assets/js/browserfs.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
</head>
<body>
<div id="root"></div>
<script type="text/javascript" src="assets/js/loader.js"></script>
<script type="text/javascript" src="assets/js/intro.min.js"></script>
<script type="text/javascript" src="assets/js/parser/antlr.js"></script>
<script src="runtime.0.41.1.1705618890572.js" type="module"></script><script src="polyfills.0.41.1.1705618890572.js" type="module"></script><script src="main.0.41.1.1705618890572.js" type="module"></script></body>
</html>